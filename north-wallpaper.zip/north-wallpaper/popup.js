(() => {
  'use strict';
  const { DEF, PRESET, NAMES } = NWEngine;
  const KEY = 'nwSettings2', IMG = 'nwImage';
  const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
  let S = { ...DEF }, img = null, saveTimer;
  const thumbs = {};

  // 模様サムネイル（実際の描画エンジンで静止画を生成）
  $('#grid').innerHTML = Object.keys(NAMES).map(k =>
    `<button type="button" class="t" data-type="${k}" title="${NAMES[k]}"><canvas></canvas><span>${NAMES[k]}</span></button>`).join('');
  for (const b of $$('.t')) {
    const k = b.dataset.type, e = NWEngine(b.querySelector('canvas')); thumbs[k] = e;
    if (k === 'image') continue;
    const [c1, c2] = PRESET[k];
    e.resize(480, 300, .2); e.update({ ...DEF, type: k, c1, c2, anim: false, veil: 0, blur: 0 }); e.seek(7);
  }
  function drawImageThumb() {
    const e = thumbs.image; e.resize(480, 300, .2); e.update({ ...DEF, type: 'image', anim: false, veil: 0, blur: 0 }, img); e.seek(0);
  }

  function save() { clearTimeout(saveTimer); saveTimer = setTimeout(() => chrome.storage.local.set({ [KEY]: S }), 100); }

  function sync() {
    $$('[data-k]').forEach(el => {
      const v = S[el.dataset.k];
      if (el.type === 'checkbox') el.checked = !!v; else el.value = v;
      const out = el.parentElement.querySelector('output');
      if (out) out.textContent = el.dataset.k === 'speed' ? `×${(+v).toFixed(1)}` : v;
    });
    $$('.t').forEach(b => b.classList.toggle('on', b.dataset.type === S.type));
    $('#colorRow').hidden = S.type === 'image';
    $('#speedRow').hidden = !S.anim;
    $('#frameRow').hidden = !S.frames;
  }

  document.addEventListener('input', e => {
    const k = e.target.dataset && e.target.dataset.k; if (!k) return;
    S[k] = e.target.type === 'checkbox' ? e.target.checked : e.target.type === 'range' ? +e.target.value : e.target.value;
    save(); sync();
  });
  $('#grid').addEventListener('click', e => {
    const b = e.target.closest('.t'); if (!b) return;
    if (b.dataset.type === 'image' && !img) { openUpload(); return; }
    S.type = b.dataset.type; S.on = true;
    if (S.type !== 'image') [S.c1, S.c2] = PRESET[S.type];
    save(); sync();
  });
  // ポップアップ内でファイル選択するとMac等で閉じてしまうため、小さな専用ウィンドウで選ぶ
  function openUpload() { chrome.windows.create({ url: 'upload.html', type: 'popup', width: 440, height: 320 }); window.close(); }
  $('#up').onclick = openUpload;
  $('#reset').onclick = () => { S = { ...DEF }; save(); sync(); };

  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch[IMG]) { const i = new Image(); i.onload = () => { img = i; drawImageThumb(); }; i.src = ch[IMG].newValue; }
    if (ch[KEY] && JSON.stringify(ch[KEY].newValue) !== JSON.stringify(S)) { S = { ...DEF, ...ch[KEY].newValue }; sync(); }
  });

  (async () => {
    const d = await chrome.storage.local.get([KEY, IMG]);
    S = { ...DEF, ...(d[KEY] || {}) }; sync(); drawImageThumb();
    if (d[IMG]) { const i = new Image(); i.onload = () => { img = i; drawImageThumb(); }; i.src = d[IMG]; }
  })();
})();
