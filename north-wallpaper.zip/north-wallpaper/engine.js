// 壁紙の描画エンジン（content / popup / upload で共用）
(() => {
  const TAU = Math.PI * 2;
  const rnd = i => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
  const md = (a, n) => ((a % n) + n) % n;
  const rgbOf = c => { const n = parseInt(c.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  const mixA = (a, b, k) => { const A = rgbOf(a), B = rgbOf(b); return A.map((v, i) => Math.round(v + (B[i] - v) * k)); };
  const rgbaA = (arr, a) => `rgba(${arr[0]},${arr[1]},${arr[2]},${a})`;
  const rgba = (c, a) => rgbaA(rgbOf(c), a);
  const mix = (a, b, k) => `rgb(${mixA(a, b, k)})`;

  function NWEngine(cv) {
    const ctx = cv.getContext('2d');
    let S = null, img = null, W = 0, H = 0, clock = 0, last = 0, raf = 0, st = {}, lastType = null;

    function base(c) {
      ctx.fillStyle = c; ctx.fillRect(0, 0, W, H);
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, 'rgba(255,255,255,.12)'); g.addColorStop(1, 'rgba(0,0,0,.5)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    }
    const glow = (x, y, r, col, a) => {
      const g = ctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, rgbaA(col, a)); g.addColorStop(.35, rgbaA(col, a * .4)); g.addColorStop(1, rgbaA(col, 0));
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    };

    const R = {
      gradient(t) {
        const a = S.anim ? t * 0.15 : 0.8, r = Math.hypot(W, H) / 2, cx = W / 2, cy = H / 2;
        const g = ctx.createLinearGradient(cx - Math.cos(a) * r, cy - Math.sin(a) * r, cx + Math.cos(a) * r, cy + Math.sin(a) * r);
        g.addColorStop(0, S.c1); g.addColorStop(1, S.c2);
        ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      },
      mesh(t) {
        ctx.fillStyle = S.c1; ctx.fillRect(0, 0, W, H);
        const A = rgbOf(S.c2), B = mixA(S.c2, '#ffffff', .35), C = mixA(S.c1, S.c2, .5), cs = [A, B, C, A];
        const r = Math.max(W, H) * .55;
        for (let i = 0; i < 4; i++) {
          const cx = W * (.5 + .4 * Math.sin(t * .2 + i * 1.9)), cy = H * (.5 + .4 * Math.cos(t * .17 + i * 2.3));
          const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
          g.addColorStop(0, rgbaA(cs[i], .8)); g.addColorStop(1, rgbaA(cs[i], 0));
          ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
        }
      },
      aurora(t) {
        const g0 = ctx.createLinearGradient(0, 0, 0, H);
        g0.addColorStop(0, '#01040c'); g0.addColorStop(1, mix(S.c1, '#000000', .2));
        ctx.fillStyle = g0; ctx.fillRect(0, 0, W, H);
        ctx.globalCompositeOperation = 'lighter';
        const cols = [rgbOf(S.c2), mixA(S.c2, '#7a5cff', .5), mixA(S.c2, '#ffffff', .3)];
        for (let i = 0; i < 3; i++) {
          const gr = ctx.createLinearGradient(0, H * .1, 0, H * .85);
          gr.addColorStop(0, rgbaA(cols[i], 0)); gr.addColorStop(.35, rgbaA(cols[i], .45)); gr.addColorStop(1, rgbaA(cols[i], 0));
          ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(0, H * .9);
          for (let x = 0; x <= W + 10; x += 10)
            ctx.lineTo(x, H * .3 + i * H * .07 + Math.sin(x * .0035 + t * .35 + i * 1.7) * H * .08 + Math.sin(x * .009 - t * .25 + i) * H * .03);
          ctx.lineTo(W + 10, H * .9); ctx.closePath(); ctx.fill();
        }
      },
      wave(t) {
        base(S.c1); ctx.fillStyle = S.c2;
        for (let i = 0; i < 5; i++) {
          const y0 = H * (.38 + i * .12), a = 16 + i * 6, k = .006 - i * .0007;
          ctx.beginPath(); ctx.moveTo(0, H);
          for (let x = 0; x <= W + 8; x += 8)
            ctx.lineTo(x, y0 + Math.sin(x * k + t * (.5 + i * .12) + i * 1.7) * a + Math.sin(x * k * .45 - t * .35 + i) * a * .7);
          ctx.lineTo(W + 8, H); ctx.closePath();
          ctx.globalAlpha = .1 + i * .06; ctx.fill();
        }
        ctx.globalAlpha = 1;
      },
      neon(t) {
        const hor = H * .55, cx = W / 2, Rr = Math.min(W, H) * .2, cy = hor - Rr * .35;
        let g = ctx.createLinearGradient(0, 0, 0, H);
        g.addColorStop(0, '#05010d'); g.addColorStop(.55, '#12041f'); g.addColorStop(1, '#05010d');
        ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
        ctx.save(); ctx.beginPath(); ctx.rect(0, 0, W, hor); ctx.clip();
        g = ctx.createLinearGradient(0, cy - Rr, 0, cy + Rr); g.addColorStop(0, S.c2); g.addColorStop(1, S.c1);
        ctx.shadowColor = S.c1; ctx.shadowBlur = 40; ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(cx, cy, Rr, 0, TAU); ctx.fill(); ctx.restore();
        ctx.lineWidth = 1.5; ctx.strokeStyle = S.c1; ctx.shadowColor = S.c1; ctx.shadowBlur = 10;
        const off = (t * .35) % 1, N = 16;
        ctx.beginPath(); ctx.moveTo(0, hor); ctx.lineTo(W, hor);
        for (let i = 0; i < N; i++) { const z = (i + off) / N, y = hor + (H - hor) * z * z; ctx.moveTo(0, y); ctx.lineTo(W, y); }
        for (let i = -14; i <= 14; i++) { ctx.moveTo(cx + i * W * .012, hor); ctx.lineTo(cx + i * W * .14, H); }
        ctx.stroke();
      },
      stars(t) {
        const g = ctx.createLinearGradient(0, 0, 0, H);
        g.addColorStop(0, '#02030a'); g.addColorStop(1, S.c1);
        ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
        if (!st.s) st.s = Array.from({ length: Math.floor(W * H / 2500) }, () => ({
          x: Math.random() * W, y: Math.random() * H, r: Math.random() * 1.4 + .3, p: Math.random() * TAU, f: Math.random() * 2 + .5 }));
        ctx.fillStyle = S.c2;
        for (const s of st.s) {
          ctx.globalAlpha = S.anim ? .35 + .65 * Math.sin(t * s.f + s.p) ** 2 : .4 + .6 * (s.r / 1.7);
          ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, TAU); ctx.fill();
        }
        ctx.globalAlpha = 1;
        if (S.anim) {
          if (!st.sh && Math.random() < .006) st.sh = { x: Math.random() * W * .7, y: Math.random() * H * .4, p: 0 };
          const s = st.sh;
          if (s) {
            s.p += .025;
            const dx = W * .3, dy = H * .2, q = Math.max(0, s.p - .2);
            const hx = s.x + dx * s.p, hy = s.y + dy * s.p, tx = s.x + dx * q, ty = s.y + dy * q;
            const lg = ctx.createLinearGradient(tx, ty, hx, hy);
            lg.addColorStop(0, 'rgba(255,255,255,0)'); lg.addColorStop(1, '#fff');
            ctx.strokeStyle = lg; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(hx, hy); ctx.stroke();
            if (s.p > 1.2) st.sh = null;
          }
        }
      },
      soda(t) {
        base(S.c1);
        if (!st.b) st.b = Array.from({ length: Math.max(20, Math.floor(W * H / 9000)) }, () => ({
          x: Math.random() * W, y: Math.random() * H, r: 2 + Math.random() ** 2 * 14, v: 15 + Math.random() * 45,
          p: Math.random() * TAU, w: .5 + Math.random() }));
        ctx.lineWidth = 1;
        for (const b of st.b) {
          const y = H + b.r - ((b.y + t * b.v) % (H + b.r * 2)), x = b.x + Math.sin(t * b.w + b.p) * 8;
          ctx.beginPath(); ctx.arc(x, y, b.r, 0, TAU);
          ctx.fillStyle = S.c2; ctx.globalAlpha = .1; ctx.fill();
          ctx.strokeStyle = S.c2; ctx.globalAlpha = .55; ctx.stroke();
          ctx.beginPath(); ctx.arc(x - b.r * .35, y - b.r * .35, b.r * .22, 0, TAU);
          ctx.fillStyle = '#fff'; ctx.globalAlpha = .7; ctx.fill();
        }
        ctx.globalAlpha = 1;
      },
      bokeh(t) {
        base(S.c1); ctx.globalCompositeOperation = 'lighter';
        const cs = [rgbOf(S.c2), mixA(S.c2, '#ffffff', .5), mixA(S.c1, S.c2, .6)];
        for (let i = 0; i < 30; i++) {
          const r = Math.max(W, H) * (.03 + rnd(i + 3) * .07), x = rnd(i) * W + Math.sin(t * .2 + i) * 30;
          const y = md(rnd(i + 50) * H - t * (5 + rnd(i + 9) * 12), H + 2 * r) - r, col = cs[i % 3];
          ctx.beginPath(); ctx.arc(x, y, r, 0, TAU);
          ctx.fillStyle = rgbaA(col, .13); ctx.fill(); ctx.strokeStyle = rgbaA(col, .35); ctx.lineWidth = 1.5; ctx.stroke();
        }
      },
      fireflies(t) {
        base(S.c1); ctx.globalCompositeOperation = 'lighter'; const col = rgbOf(S.c2);
        for (let i = 0; i < 70; i++) {
          const x = rnd(i) * W + Math.sin(t * (.15 + rnd(i + 1) * .3) + i * 3) * 70;
          const y = rnd(i + 2) * H + Math.cos(t * (.12 + rnd(i + 3) * .3) + i * 5) * 60;
          const a = .25 + .75 * Math.sin(t * (.6 + rnd(i + 4)) + i) ** 2;
          glow(x, y, (4 + rnd(i + 5) * 8) * 3, col, a);
        }
      },
      rain(t) {
        base(S.c1); ctx.strokeStyle = rgba(S.c2, .45); ctx.lineWidth = 1; ctx.beginPath();
        for (let i = 0, n = Math.floor(W / 5); i < n; i++) {
          const v = 500 + rnd(i + 1) * 400, len = 18 + rnd(i + 2) * 30, x = rnd(i) * (W + H * .15);
          const y = md(rnd(i + 3) * H + t * v, H + len) - len;
          ctx.moveTo(x - y * .12, y); ctx.lineTo(x - (y + len) * .12, y + len);
        }
        ctx.stroke();
      },
      snow(t) {
        base(S.c1); ctx.fillStyle = rgba(S.c2, .85);
        for (let i = 0, n = Math.max(60, Math.floor(W * H / 8000)); i < n; i++) {
          const r = 1 + rnd(i + 1) * 3.5, x = rnd(i) * W + Math.sin(t * .5 + i) * 20, y = md(rnd(i + 2) * H + t * (18 + r * 10), H + 10) - 5;
          ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
        }
      },
      sakura(t) {
        base(S.c1); ctx.fillStyle = rgba(S.c2, .85);
        for (let i = 0; i < 50; i++) {
          const s = 5 + rnd(i + 1) * 6, x = md(rnd(i) * W + t * (15 + rnd(i + 2) * 20) + Math.sin(t + i) * 30, W);
          const y = md(rnd(i + 3) * H + t * (28 + rnd(i + 4) * 30), H + 20) - 10;
          ctx.save(); ctx.translate(x, y); ctx.rotate(t * (.4 + rnd(i + 5)) + i); ctx.scale(1, .5 + .5 * Math.cos(t + i));
          ctx.beginPath(); ctx.ellipse(0, 0, s, s * .55, 0, 0, TAU); ctx.fill(); ctx.restore();
        }
      },
      matrix(t) {
        ctx.fillStyle = mix(S.c1, '#000000', .4); ctx.fillRect(0, 0, W, H);
        const CH = 'ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄ0123456789', fs = 18;
        ctx.font = `${fs}px monospace`; ctx.textBaseline = 'top';
        for (let c = 0, cols = Math.ceil(W / fs); c < cols; c++) {
          const head = md(rnd(c + 2) * H * 2 + t * (40 + rnd(c + 1) * 110), H * 1.6);
          for (let k = 0; k < 14; k++) {
            const y = head - k * fs; if (y < -fs || y > H) continue;
            ctx.fillStyle = k === 0 ? '#fff' : rgba(S.c2, 1 - k / 14);
            ctx.fillText(CH[Math.floor(t * (3 + rnd(c + 3) * 5) + k * 7 + c * 13) % CH.length], c * fs, y);
          }
        }
      },
      cybergrid(t) {
        base(S.c1); const s = 48, o = (t * 18) % s;
        ctx.strokeStyle = rgba(S.c2, .28); ctx.lineWidth = 1; ctx.beginPath();
        for (let x = -s + o; x < W + s; x += s) { ctx.moveTo(x, 0); ctx.lineTo(x, H); }
        for (let y = -s + o; y < H + s; y += s) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
        ctx.stroke();
        const by = md(t * 70, H + 200) - 100, g = ctx.createLinearGradient(0, by - 100, 0, by + 100);
        g.addColorStop(0, rgba(S.c2, 0)); g.addColorStop(.5, rgba(S.c2, .25)); g.addColorStop(1, rgba(S.c2, 0));
        ctx.fillStyle = g; ctx.fillRect(0, by - 100, W, 200);
      },
      hex(t) {
        base(S.c1); const r = 34, w = Math.sqrt(3) * r, h = 1.5 * r, cx = W / 2, cy = H / 2; ctx.lineWidth = 1.2;
        for (let row = -1; row * h < H + r; row++) for (let col = -1; col * w < W + w; col++) {
          const x = col * w + (row & 1 ? w / 2 : 0), y = row * h;
          const p = Math.max(0, Math.sin(Math.hypot(x - cx, y - cy) / 90 - t * 1.4));
          ctx.strokeStyle = rgba(S.c2, .1 + .55 * p ** 4); ctx.beginPath();
          for (let k = 0; k < 6; k++) { const an = Math.PI / 3 * k + Math.PI / 6, px = x + r * Math.cos(an), py = y + r * Math.sin(an); k ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
          ctx.closePath(); ctx.stroke();
        }
      },
      dots(t) {
        base(S.c1); ctx.fillStyle = rgba(S.c2, .55); const s = 34;
        for (let row = 0, y = s / 2; y < H + s; y += s, row++) for (let x = s / 2; x < W + s; x += s) {
          const r = 2 + 5 * (.5 + .5 * Math.sin((x + y) * .012 - t * 1.6));
          ctx.beginPath(); ctx.arc(x + (row & 1 ? s / 2 : 0), y, r, 0, TAU); ctx.fill();
        }
      },
      stripes(t) {
        ctx.fillStyle = S.c1; ctx.fillRect(0, 0, W, H);
        ctx.translate(W / 2, H / 2); ctx.rotate(-.6);
        const d = Math.hypot(W, H), sw = 70, o = (t * 25) % (sw * 2);
        ctx.fillStyle = rgba(S.c2, .4);
        for (let x = -d - sw * 2 + o; x < d; x += sw * 2) ctx.fillRect(x, -d, sw, d * 2);
      },
      checker(t) {
        ctx.fillStyle = S.c1; ctx.fillRect(0, 0, W, H);
        const s = 72, o = (t * 14) % (s * 2); ctx.fillStyle = rgba(S.c2, .3);
        for (let iy = -2; iy * s < H + s; iy++) for (let ix = -2; ix * s < W + s; ix++)
          if ((ix + iy) & 1) ctx.fillRect(ix * s + o, iy * s + o, s, s);
      },
      ripple(t) {
        base(S.c1); ctx.lineWidth = 2;
        for (let i = 0; i < 3; i++) {
          const cx = W * (.2 + rnd(i) * .6), cy = H * (.2 + rnd(i + 9) * .6);
          for (let k = 0; k < 6; k++) {
            const r = md(t * 45 + k * 80 + i * 60, 480);
            ctx.strokeStyle = rgba(S.c2, (1 - r / 480) * .6); ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.stroke();
          }
        }
      },
      sunburst(t) {
        if (!ctx.createConicGradient) return R.gradient(t);
        const g = ctx.createConicGradient(t * .12, W / 2, H / 2), n = 24;
        for (let i = 0; i < n; i++) { const c = i % 2 ? S.c2 : S.c1; g.addColorStop(i / n, c); g.addColorStop(Math.min(1, (i + 1) / n - .0005), c); }
        ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
        const v = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, Math.hypot(W, H) / 2);
        v.addColorStop(0, 'rgba(255,255,255,.18)'); v.addColorStop(1, 'rgba(0,0,0,.3)');
        ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
      },
      silk(t) {
        base(S.c1); ctx.lineWidth = 1; const n = 36;
        for (let j = 0; j < n; j++) {
          ctx.strokeStyle = rgba(S.c2, .12 + .2 * (j / n)); ctx.beginPath();
          for (let x = 0; x <= W; x += 14) {
            const y = H * .5 + (j - n / 2) * 9 + Math.sin(x * .0038 + t * .35 + j * .16) * H * .22 * Math.sin(j * .09 + t * .12 + 1);
            x ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
          }
          ctx.stroke();
        }
      },
      confetti(t) {
        base(S.c1); const cs = [rgbOf(S.c2), mixA(S.c2, '#ffffff', .55), mixA(S.c2, S.c1, .5), [255, 255, 255]];
        for (let i = 0; i < 60; i++) {
          const x = rnd(i) * W + Math.sin(t + i) * 20, y = md(rnd(i + 1) * H + t * (35 + rnd(i + 2) * 50), H + 20) - 10;
          ctx.save(); ctx.translate(x, y); ctx.rotate(t * (1 + rnd(i + 3) * 2) + i); ctx.scale(1, Math.cos(t * 2 + i));
          ctx.fillStyle = rgbaA(cs[i % 4], .9); ctx.fillRect(-5, -2.5, 10, 5); ctx.restore();
        }
      },
      image(t) {
        ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
        if (!img) return;
        const sc = Math.max(W / img.width, H / img.height) * (S.anim ? 1.06 + .05 * Math.sin(t * .2) : 1.02);
        const w = img.width * sc, h = img.height * sc, ox = S.anim ? Math.sin(t * .13) * (w - W) * .4 : 0;
        ctx.drawImage(img, (W - w) / 2 + ox, (H - h) / 2, w, h);
      }
    };

    function draw(t) {
      if (!S || !W || !H) return;
      ctx.clearRect(0, 0, W, H); ctx.save();
      (R[S.type] || R.gradient)(t);
      ctx.restore();
      if (S.veil > 0) { ctx.fillStyle = `rgba(0,0,0,${S.veil / 100})`; ctx.fillRect(0, 0, W, H); }
    }
    function loop(now) {
      raf = requestAnimationFrame(loop);
      if (document.hidden || now - last < 33) return;
      clock += Math.min((now - last) / 1000, .1) * S.speed; last = now;
      draw(clock);
    }
    function stop() { cancelAnimationFrame(raf); raf = 0; }
    function start() {
      stop();
      if (S.anim) { last = performance.now(); raf = requestAnimationFrame(loop); }
      draw(clock);
    }

    return {
      resize(w, h, scale) {
        const dpr = Math.min(devicePixelRatio || 1, 1.5) * (scale || 1);
        W = w || cv.clientWidth; H = h || cv.clientHeight; if (!W || !H) return;
        cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        st = {}; draw(clock);
      },
      update(s, image) {
        S = s; if (image !== undefined) img = image;
        if (S.type !== lastType) { st = {}; lastType = S.type; }
        cv.style.filter = S.blur ? `blur(${S.blur}px)` : '';
        cv.style.transform = S.blur ? 'scale(1.08)' : '';
        if (!W || !H) this.resize();
        start();
      },
      seek(t) { clock = t; draw(clock); },
      stop
    };
  }

  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  NWEngine.DEF = { on: false, type: 'gradient', c1: '#6a11cb', c2: '#2575fc', anim: !reduced, speed: 1,
                   veil: 0, blur: 0, frames: true, frame: 96, tint: 'auto' };
  NWEngine.PRESET = {
    gradient: ['#6a11cb', '#2575fc'], mesh: ['#1b1464', '#ff6ec7'], aurora: ['#07142b', '#4ade80'], wave: ['#0f2b5b', '#38bdf8'],
    neon: ['#ff2ec4', '#00e5ff'], stars: ['#0b1030', '#ffffff'], soda: ['#0a6ebd', '#bff4ff'], bokeh: ['#2a0a4a', '#ffb86b'],
    fireflies: ['#06150f', '#d9ff5a'], rain: ['#0b1220', '#9fc3ff'], snow: ['#16324f', '#ffffff'], sakura: ['#3b1a35', '#ffc2dc'],
    matrix: ['#00160a', '#33ff77'], cybergrid: ['#0a0a2a', '#00e5ff'], hex: ['#0b1030', '#3df5ff'], dots: ['#4a1a8a', '#ff9ad5'],
    stripes: ['#1f2a6b', '#5b8cff'], checker: ['#251a3d', '#8f7bff'], ripple: ['#06243d', '#4fd1ff'], sunburst: ['#ff8a00', '#ffcf33'],
    silk: ['#14061f', '#ff5ec4'], confetti: ['#3a1a6b', '#ffd54a'], image: ['#000000', '#000000'] };
  NWEngine.NAMES = {
    gradient: 'グラデーション', mesh: 'メッシュ', aurora: 'オーロラ', wave: '波', neon: 'ネオン', stars: '星空', soda: '炭酸',
    bokeh: 'ボケ', fireflies: '蛍', rain: '雨', snow: '雪', sakura: '桜', matrix: 'デジタル', cybergrid: 'グリッド', hex: 'ハニカム',
    dots: 'ドット', stripes: 'ストライプ', checker: 'チェッカー', ripple: '波紋', sunburst: '放射', silk: 'シルク', confetti: '紙吹雪', image: '画像' };
  Object.assign(NWEngine, { rgbOf, mixA, rgbaA });
  NWEngine.avg = im => {
    const c = document.createElement('canvas'); c.width = c.height = 8;
    const x = c.getContext('2d'); x.drawImage(im, 0, 0, 8, 8);
    const d = x.getImageData(0, 0, 8, 8).data; let r = 0, g = 0, b = 0;
    for (let i = 0; i < d.length; i += 4) { r += d[i]; g += d[i + 1]; b += d[i + 2]; }
    const n = d.length / 4;
    return '#' + [r, g, b].map(v => Math.round(v / n).toString(16).padStart(2, '0')).join('');
  };
  NWEngine.toDataURL = file => new Promise((res, rej) => {
    const u = URL.createObjectURL(file), im = new Image();
    im.onload = () => {
      const k = Math.min(1, 2560 / Math.max(im.width, im.height)), c = document.createElement('canvas');
      c.width = im.width * k | 0; c.height = im.height * k | 0;
      const x = c.getContext('2d'); x.fillStyle = '#000'; x.fillRect(0, 0, c.width, c.height);
      x.drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c.toDataURL('image/jpeg', .85));
    };
    im.onerror = () => { URL.revokeObjectURL(u); rej(new Error('load')); };
    im.src = u;
  });
  window.NWEngine = NWEngine;
})();
