(() => {
  'use strict';
  if (window.__nwLoaded) return; window.__nwLoaded = true;
  const { DEF, mixA, rgbOf, rgbaA } = NWEngine;
  const KEY = 'nwSettings2', IMG = 'nwImage';

  let S = { ...DEF }, img = null, avg = '#808080', cv = null, eng = null;
  let theme = 'light', lastColor = '', lastFrames = null;

  const isDark = () => (S.tint === 'auto' ? theme : S.tint) === 'dark';

  function ensure() {
    if (cv && cv.isConnected) return;
    cv = document.createElement('canvas'); cv.id = 'nw-canvas';
    document.documentElement.appendChild(cv); eng = NWEngine(cv);
  }

  function resetMarks() {
    document.querySelectorAll('[data-nw-c],[data-nw-f]').forEach(e => { e.removeAttribute('data-nw-c'); e.removeAttribute('data-nw-f'); });
  }

  // 模様の色から「枠の色」を作る（明るいサイト＝白寄りの薄い色、暗いサイト＝黒寄りの濃い色）
  function setVars() {
    const dark = isDark(), img_ = S.type === 'image';
    const bg = mixA(img_ ? avg : S.c1, dark ? '#000000' : '#ffffff', dark ? .8 : .9);
    const edge = img_ ? mixA(avg, '#ffffff', .5) : rgbOf(S.c2);
    const st = document.documentElement.style;
    st.setProperty('--nw-frame', rgbaA(bg, S.frame / 100));
    st.setProperty('--nw-edge', rgbaA(edge, .9));
  }

  // サイト本文の文字色から明るいテーマ/暗いテーマを判定
  function detectTheme() {
    const c = getComputedStyle(document.body).color;
    if (c === lastColor) return false;
    lastColor = c;
    const m = c.match(/[\d.]+/g) || [0, 0, 0];
    theme = (.299 * m[0] + .587 * m[1] + .114 * m[2]) / 255 < .5 ? 'light' : 'dark';
    return true;
  }

  function sweep() {
    if (!S.on) return;
    if (detectTheme()) { resetMarks(); setVars(); }
    const vw = innerWidth, vh = innerHeight;
    const opaque = el => {
      const bg = getComputedStyle(el).backgroundColor;
      if (!/^rgba?\(/.test(bg)) return false;
      const m = bg.match(/[\d.]+/g); return m.length < 4 || +m[3] > .05;
    };
    const big = el => { const q = el.getBoundingClientRect(); return q.width >= vw * .1 && q.height >= vh * .4; };

    (function walk(el, d) {
      if (d > 9) return;
      for (const c of el.children) {
        if (c.id === 'nw-canvas' || c.hasAttribute('data-nw-f')) continue;
        if (c.hasAttribute('data-nw-c')) { walk(c, d + 1); continue; }
        const r = c.getBoundingClientRect();
        if (r.width < vw * .1 || r.height < vh * .12) continue;          // 小さい要素はサイト本来の見た目のまま
        const op = opaque(c);
        if (r.width >= vw * .9 && r.height >= vh * .9) {                  // ページ全体の背景 → 透明にして壁紙を見せる
          if (op) c.setAttribute('data-nw-c', '');
          walk(c, d + 1); continue;
        }
        if (!S.frames) { if (!op) walk(c, d + 1); continue; }
        if (op) { if (r.height >= vh * .25) c.setAttribute('data-nw-f', ''); continue; }   // 背景つきの大きな枠 → 色を差し替え
        const wrapper = [...c.children].filter(big).length >= 2;          // 複数カラムを包むだけの要素は枠にしない
        if (!wrapper && r.height >= vh * .4 && r.width <= vw * .6 && c.textContent.trim()) c.setAttribute('data-nw-f', '');
        else walk(c, d + 1);
      }
    })(document.body, 0);
  }

  function apply() {
    const root = document.documentElement;
    root.classList.toggle('nw-on', S.on);
    if (!S.on) {
      if (eng) eng.stop(); if (cv) cv.style.display = 'none';
      resetMarks(); root.style.removeProperty('--nw-frame'); root.style.removeProperty('--nw-edge'); lastFrames = null;
      return;
    }
    ensure(); cv.style.display = ''; detectTheme();
    if (S.frames !== lastFrames) { lastFrames = S.frames; resetMarks(); }
    setVars(); eng.resize(); eng.update(S, img); sweep();
  }

  function loadImg(url) {
    if (!url) { img = null; avg = '#808080'; if (eng && S.on) { setVars(); eng.update(S, null); } return; }
    const i = new Image();
    i.onload = () => { img = i; avg = NWEngine.avg(i); if (eng && S.on) { setVars(); eng.update(S, img); } };
    i.src = url;
  }

  let timer;
  const tick = () => { clearTimeout(timer); timer = setTimeout(sweep, 300); };

  async function init() {
    let d = {};
    try { d = await chrome.storage.local.get([KEY, IMG]); } catch (e) {}
    S = { ...DEF, ...(d[KEY] || {}) };
    apply(); loadImg(d[IMG]);
    new MutationObserver(tick).observe(document.body, { childList: true, subtree: true });
    addEventListener('resize', () => { if (eng && S.on) { eng.resize(); tick(); } });
    try {
      chrome.storage.onChanged.addListener((ch, area) => {
        if (area !== 'local') return;
        if (ch[IMG]) loadImg(ch[IMG].newValue);
        if (ch[KEY]) { S = { ...DEF, ...ch[KEY].newValue }; apply(); }
      });
    } catch (e) {}
  }
  init();
})();
