(() => {
  'use strict';
  const { DEF } = NWEngine, KEY = 'nwSettings2', IMG = 'nwImage';
  const drop = document.getElementById('drop'), file = document.getElementById('file'), msg = document.getElementById('msg');

  async function handle(f) {
    if (!f || !f.type.startsWith('image/')) { msg.textContent = '画像ファイルを選んでください。'; return; }
    msg.textContent = '画像を処理中…';
    try {
      const url = await NWEngine.toDataURL(f);
      const d = await chrome.storage.local.get(KEY);
      const S = { ...DEF, ...(d[KEY] || {}), type: 'image', on: true };
      await chrome.storage.local.set({ [IMG]: url, [KEY]: S });
      msg.textContent = '背景に設定しました。';
      setTimeout(() => window.close(), 700);
    } catch (e) { msg.textContent = '画像を読み込めませんでした。別のファイルでお試しください。'; }
  }
  file.onchange = () => handle(file.files[0]);
  drop.ondragover = e => { e.preventDefault(); drop.classList.add('hover'); };
  drop.ondragleave = () => drop.classList.remove('hover');
  drop.ondrop = e => { e.preventDefault(); drop.classList.remove('hover'); handle(e.dataTransfer.files[0]); };
})();
